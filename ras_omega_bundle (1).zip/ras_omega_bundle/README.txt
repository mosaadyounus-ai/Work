RAS-Ω Artifact Bundle

Includes:
- SVG diagram
- Node map JSON

Meaning:
Recursive Anchor Sigil representing MFCS liveness topology.
