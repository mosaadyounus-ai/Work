#!/usr/bin/env bash
set -euo pipefail

# 671.6Hz Audio Test Suite — Deterministic Manifest Generator
# Rebuilds checksums.sha256 from all tracked files in alphabetical order.

ROOT="$(cd "$(dirname "$0")" && pwd)"
OUT="$ROOT/checksums.sha256"

echo "# 671.6Hz Audio Test Suite v1.0 — SHA256 Checksums" > "$OUT"
echo "# Generated: $(date -u +%Y-%m-%dT%H:%M:%SZ)" >> "$OUT"
echo "# Algorithm: SHA-256" >> "$OUT"
echo "# Deterministic: files processed in sorted order" >> "$OUT"
echo "" >> "$OUT"

find "$ROOT" -type f ! -name 'checksums.sha256' ! -name '*.zip' | sort | while read -r f; do
    rel="${f#$ROOT/}"
    hash=$(sha256sum "$f" | awk '{print $1}')
    printf '%s  %s\n' "$hash" "$rel" >> "$OUT"
done

echo "Manifest written to: $OUT"
wc -l < "$OUT"
