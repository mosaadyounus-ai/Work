# Audio Test Suite Technical Specification — 671.6 Hz

## 1. Overview

This test suite provides calibrated audio signals at **671.6 Hz**, a frequency selected for its non-integer relationship to common power-line harmonics (50/60 Hz) and its placement within the sensitive region of human hearing (≈500–4000 Hz).

## 2. Signal Definitions

### 2.1 clean.wav
- **Waveform**: Pure sinusoid
- **Frequency**: 671.6 Hz ± 0 Hz (theoretical)
- **Amplitude**: 0.9 peak (≈ -0.915 dBFS)
- **Duration**: 5.000 s
- **Sample Rate**: 44,100 Hz
- **Bit Depth**: 16-bit signed PCM
- **Channels**: 1 (mono)

### 2.2 harmonics.wav
- **Fundamental**: 671.6 Hz @ -6.02 dB relative to full scale
- **2nd harmonic**: 1343.2 Hz @ -12.04 dB
- **3rd harmonic**: 2014.8 Hz @ -18.06 dB
- **4th harmonic**: 2686.4 Hz @ -24.08 dB
- **5th harmonic**: 3358.0 Hz @ -30.10 dB
- **Total harmonic distortion (THD)**: ≈ 17.7%

### 2.3 safe.wav
- **Waveform**: Pure sinusoid
- **Frequency**: 671.6 Hz
- **Amplitude**: 0.1 peak (-20.0 dBFS)
- **Purpose**: Safe playback on unknown/consumer equipment without risk of driver damage or hearing injury

### 2.4 sweep.wav
- **Type**: Logarithmic frequency sweep
- **Range**: 100 Hz → 2000 Hz
- **Duration**: 5.000 s
- **Amplitude**: 0.9 peak
- **Purpose**: Identify resonances, frequency-response anomalies, and verify 671.6 Hz lies within the flat response region of the device under test

## 3. Analysis Artifacts

| File | Method | Description |
|------|--------|-------------|
| spectrum_analysis.png | FFT (full length, rectangular window) | Frequency-domain verification of clean tone purity |
| spectrogram.png | STFT (4096-sample Hann window, 50% overlap) | Time-frequency visualization of sweep |
| comparison.png | Time-domain overlay | Waveform morphology comparison (first 22.7 ms) |

## 4. Determinism & Reproducibility

1. **Audio generation**: Uses deterministic `numpy` arrays with fixed seeding logic (no randomness).
2. **File ordering**: All files sorted alphabetically before ZIP construction.
3. **ZIP metadata**: Built with `zip -X` to exclude extended timestamps and OS-specific attributes.
4. **Checksum chain**: `checksums.sha256` anchors every file; regenerating yields identical hashes on identical content.

## 5. Verification Procedure

```bash
# 1. Unzip
unzip 671_6Hz_Audio_Test_Suite_v1.0.zip

# 2. Verify checksums
cd 671_6Hz_Audio_Test_Suite_v1.0
sha256sum -c checksums.sha256

# 3. Regenerate manifest (should match)
./GENERATE_MANIFEST.sh
diff checksums.sha256 checksums.sha256  # trivially true, or compare with original

# 4. Validate JSON schema
python3 -m json.tool MANIFEST.schema.json > /dev/null && echo "Schema valid JSON"
```

## 6. References

- IEC 60268-1: Sound system equipment — General
- ITU-R BS.468-4: Measurement of audio-frequency noise voltage level
- SciPy signal processing documentation (v1.x)
