# 671.6 Hz Audio Test Suite v1.0

A deterministic, reproducible audio test package centered on the **671.6 Hz** frequency.

## Package Structure

```
671_6Hz_Audio_Test_Suite_v1.0/
├── audio/
│   ├── clean.wav      — Pure 671.6 Hz sine wave (90% peak, 5 s, 44.1 kHz)
│   ├── harmonics.wav  — Fundamental + 2nd–5th harmonics
│   ├── safe.wav       — Attenuated -20 dBFS version for safe playback
│   └── sweep.wav      — Logarithmic sweep 100 Hz → 2000 Hz
├── analysis/
│   ├── comparison.png       — Waveform comparison (first 22.7 ms)
│   ├── spectrogram.png      — Time-frequency analysis of sweep
│   └── spectrum_analysis.png — FFT spectrum of clean tone
├── docs/
│   └── AUDIO_TEST_SUITE_671_6HZ.md — Full technical specification
├── GENERATE_MANIFEST.sh   — Reproducible manifest generator
├── MANIFEST.schema.json   — Schema for manifest validation
└── checksums.sha256       — Cryptographic integrity anchor
```

## Quick Start

```bash
# Verify integrity
sha256sum -c checksums.sha256

# Regenerate manifest (deterministic)
./GENERATE_MANIFEST.sh
```

## Determinism Guarantees

- All files ordered alphabetically within each directory
- ZIP built with `-X` (no extra metadata / timestamps)
- Bit-for-bit reproducible rebuilds
- Zero hidden payloads — all placeholders replaced with real data

## License

Public domain. Verify, don't trust.
