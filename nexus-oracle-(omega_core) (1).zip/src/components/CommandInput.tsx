import React, { useState } from "react";
import { useCodex } from "../context/CodexContext";
import { Terminal, Send, Zap, Shield, Cpu, History, Sparkles } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const commands = [
  { id: "STABILIZE", icon: Shield, label: "Stabilize", desc: "Dampen lattice variance" },
  { id: "BOOST", icon: Zap, label: "Boost", desc: "Ignite system energy" },
  { id: "PREDICTION", icon: Cpu, label: "Simulate", desc: "Project ghost futures" },
  { id: "TRACE", icon: History, label: "Trace", desc: "Recall state history" },
  { id: "ORACLE", icon: Sparkles, label: "Oracle", desc: "AI strategic analysis" }
] as const;

export default function CommandInput() {
  const [input, setInput] = useState("");
  const { sendIntent, lastAck, runOracleAnalysis, isAnalyzing } = useCodex();
  const [isFocused, setIsFocused] = useState(false);

  const handleCommand = (cmd: string) => {
    if (!cmd.trim()) return;
    const action = cmd.toUpperCase();
    
    if (action === "ORACLE") {
      runOracleAnalysis();
      setInput("");
      return;
    }

    // Auto-meta for specific commands
    const meta = action === "PREDICTION" ? { steps: 50 } : (action === "TRACE" ? { limit: 100 } : undefined);
    
    sendIntent(action, meta);
    setInput("");
  };

  return (
    <div className="w-[480px] group">
      <div className={`relative flex items-center bg-[#0a1118cc] border transition-all duration-300 backdrop-blur-md px-4 py-2 rounded-xs shadow-[0_0_25px_rgba(0,0,0,0.5)] ${
        isFocused ? 'border-[#00eaff] shadow-[0_0_15px_rgba(0,234,255,0.15)]' : 'border-[#1a3a45]'
      }`}>
        <Terminal size={14} className={`mr-4 ${isFocused || isAnalyzing ? 'text-[#00eaff]' : 'text-[#8899a6]'}`} />
        
        <input 
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleCommand(input)}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
          placeholder={isAnalyzing ? "Oracle Inference in progress..." : "System Command Entry [intent_initiate]..."}
          disabled={isAnalyzing}
          className="flex-1 bg-transparent border-none outline-none text-[11px] uppercase tracking-widest text-[#00eaff] placeholder:text-[#1a3a45] placeholder:italic"
        />

        <button 
          onClick={() => handleCommand(input)}
          disabled={isAnalyzing}
          className="ml-4 p-1.5 hover:bg-[#00eaff11] rounded-xs transition-colors disabled:opacity-50"
        >
          {isAnalyzing ? <div className="w-3.5 h-3.5 border-2 border-[#00eaff] border-t-transparent rounded-full animate-spin" /> : <Send size={14} className="text-[#00eaff]" />}
        </button>

        {/* ACK Indicator */}
        <AnimatePresence>
          {lastAck && (
            <motion.div 
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0 }}
              className="absolute -top-1 -right-1 w-2 h-2 bg-[#00ff41] rounded-full shadow-[0_0_8px_rgba(0,255,65,0.8)]"
            />
          )}
        </AnimatePresence>
      </div>

      {/* Suggested Command Chips */}
      <div className="flex gap-2 mt-3 overflow-hidden">
        {commands.map(cmd => (
          <button
            key={cmd.id}
            onClick={() => handleCommand(cmd.id)}
            className="flex items-center gap-2 px-3 py-1.5 bg-[#05070a99] border border-[#1a3a4566] hover:border-[#00eaff33] hover:bg-[#00eaff08] transition-all group/btn"
          >
            <cmd.icon size={10} className="text-[#8899a6] group-hover/btn:text-[#00eaff] transition-colors" />
            <span className="text-[8px] uppercase tracking-wider text-[#8899a6] group-hover/btn:text-[#fff]">{cmd.label}</span>
          </button>
        ))}
      </div>

      {/* History / Status Tooltip */}
      <div className="mt-2 pl-2">
        {lastAck ? (
          <div className="text-[7px] uppercase tracking-widest text-[#00ff41] flex items-center gap-2 opacity-60">
            <div className="w-1 h-1 rounded-full bg-[#00ff41] animate-pulse" />
            Last_Command: {lastAck.action} // Status: {lastAck.status}
          </div>
        ) : (
          <div className="text-[7px] uppercase tracking-widest text-[#1a3a45] italic">
            Waiting for operator intent...
          </div>
        )}
      </div>
    </div>
  );
}
