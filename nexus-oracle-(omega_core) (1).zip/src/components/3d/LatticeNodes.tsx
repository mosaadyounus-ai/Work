/// <reference types="@react-three/fiber" />
import { useFrame } from "@react-three/fiber";
import { useRef, useMemo, useState, useEffect } from "react";
import * as THREE from "three";
import { Html } from "@react-three/drei";
import { PathState } from "../../lib/types";
import { getNodePosition } from "./latticeLayout";

interface LatticeNodesProps {
  paths: PathState[];
  selectedId?: string;
  targetId?: string;
  onSelect: (id: string) => void;
}

const colorTemp = new THREE.Color();
const dummy = new THREE.Object3D();

export function LatticeNodes({ paths, selectedId, targetId, onSelect }: LatticeNodesProps) {
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const [hoveredIdx, setHovered] = useState<number | null>(null);
  
  const NODES_PER_QUADRANT = 250;
  
  // Static positions generated once
  const positions = useMemo(() => {
    return paths.map((_, i) => getNodePosition(i % NODES_PER_QUADRANT, Math.floor(i / NODES_PER_QUADRANT)));
  }, [paths.length]);

  const getColor = (path: PathState, isSelected: boolean, isTarget: boolean) => {
    if (isSelected) return "#ffffff";
    if (isTarget) return "#00eaff";
    const e = path.value / 100;
    if (e > 0.8) return "#00eaff";
    if (e > 0.5) return "#00ff41";
    if (e > 0.2) return "#ffcc00";
    return "#1a3a45";
  };

  useFrame((state) => {
    if (!meshRef.current) return;

    paths.forEach((path, i) => {
      const pos = positions[i];
      const isSelected = selectedId === path.id;
      const isTarget = targetId === path.id;
      const isHovered = hoveredIdx === i;
      
      const activeState = isSelected || isTarget;
      const baseScale = activeState ? 2.5 : 1.0;
      const energyPulseSpeed = (path.value / 100) * 5 + 1;
      const pulse = Math.sin(state.clock.elapsedTime * energyPulseSpeed + i) * (path.value / 400);
      
      const scale = baseScale + pulse + (isHovered ? 0.5 : 0);
      
      dummy.position.set(pos[0], pos[1], pos[2]);
      dummy.scale.setScalar(scale * (0.4 + (path.importance || 0) * 0.4));
      dummy.updateMatrix();
      
      meshRef.current.setMatrixAt(i, dummy.matrix);
      
      colorTemp.set(getColor(path, isSelected, isTarget));
      meshRef.current.setColorAt(i, colorTemp);
    });
    
    meshRef.current.instanceMatrix.needsUpdate = true;
    if (meshRef.current.instanceColor) meshRef.current.instanceColor.needsUpdate = true;
  });

  const hoveredPath = hoveredIdx !== null ? paths[hoveredIdx] : null;
  const selectedPath = paths.find(p => p.id === selectedId);
  const activeLabelPath = hoveredPath || selectedPath;
  const activeLabelPos = activeLabelPath ? positions[paths.indexOf(activeLabelPath)] : null;

  return (
    <group>
      <instancedMesh 
        ref={meshRef} 
        args={[undefined, undefined, paths.length]} 
        onClick={(e) => {
          e.stopPropagation();
          if (e.instanceId !== undefined) onSelect(paths[e.instanceId].id);
        }}
        onPointerOver={(e) => {
          if (e.instanceId !== undefined) setHovered(e.instanceId);
        }}
        onPointerOut={() => setHovered(null)}
      >
        <sphereGeometry args={[1, 12, 12]} />
        <meshStandardMaterial 
          transparent 
          opacity={0.9} 
          toneMapped={false}
        />
      </instancedMesh>

      {activeLabelPath && activeLabelPos && (
        <group position={activeLabelPos}>
          <Html distanceFactor={15} center position={[0, 2, 0]}>
            <div className="glass-panel p-3 border border-[#00eaff33] rounded-xs pointer-events-none whitespace-nowrap shadow-[0_0_25px_rgba(0,234,255,0.2)]">
              <div className="text-[10px] text-[#00eaff] font-black uppercase tracking-[0.2em]">{activeLabelPath.id}</div>
              <div className="flex gap-3 mt-2 border-t border-[#1a3a45] pt-2">
                <div className="flex flex-col">
                  <span className="text-[7px] text-[#8899a6] uppercase font-bold">Potential</span>
                  <span className="text-[9px] text-[#00ff41] font-mono">{(activeLabelPath.value/100).toFixed(2)}</span>
                </div>
                <div className="flex flex-col">
                  <span className="text-[7px] text-[#8899a6] uppercase font-bold">Resonance</span>
                  <span className="text-[9px] text-[#ffcc00] font-mono">{activeLabelPath.momentum.toFixed(0)}</span>
                </div>
              </div>
            </div>
          </Html>
        </group>
      )}
    </group>
  );
}
