import { useCodex } from "../context/CodexContext";
import LatticeScene from "../components/3d/LatticeScene";
import { motion, AnimatePresence } from "framer-motion";
import { Shield, Activity, Share2, Target, Zap, LayoutGrid, AlertCircle, TrendingUp, Cpu } from "lucide-react";
import CommandInput from "../components/CommandInput";
import Notifications from "../components/Notifications";

export default function LatticePage() {
  const { 
    meridian, 
    focusMode, 
    setFocusMode, 
    selectedSignalId, 
    setSelectedSignal,
    phi,
    readiness,
    energy,
    rateLimitState
  } = useCodex();

  // We map the state for the scene
  const state = meridian ? { 
    telemetry: {
       SVI: meridian.vitalityIndex,
       OM: meridian.operationalMomentum,
       AP: meridian.anomalyPressure,
       pathMap: meridian.pathMap
    },
    ui: {
       selectedSignalId,
       focusMode
    }
  } : null;

  const handleSelectNode = (id: string) => {
    setSelectedSignal(id);
  };

  if (!state) {
    return (
      <div className="h-screen w-full bg-[#05070a] flex items-center justify-center">
        <div className="space-y-4 text-center">
          <div className="w-12 h-12 border-2 border-[#00eaff] border-t-transparent rounded-full animate-spin mx-auto" />
          <div className="text-[10px] text-[#00eaff] uppercase tracking-[0.4em] font-black animate-pulse">Initializing_Lattice_Mesh</div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen w-full relative overflow-hidden bg-[#05070a]">
      {/* 3D Visualizer */}
      <div className="absolute inset-0">
        <LatticeScene state={state} onSelectNode={handleSelectNode} />
      </div>

      {/* COMMAND CONTROL GRID */}
      <div className="absolute top-6 left-1/2 -translate-x-1/2 z-50 pointer-events-auto">
        <CommandInput />
      </div>

      {/* Left Sidebar: Stability Conservation — NEW REFINE */}
      <div className="absolute top-24 left-6 space-y-6 pointer-events-none p-4 glass-panel glow-border">
        <div className="space-y-4">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-[9px] uppercase tracking-[0.3em] text-[#8899a6] font-black">System_Vitality</h3>
            {rateLimitState === 'THROTTLED' && (
              <div className="flex items-center gap-1.5 px-2 py-0.5 bg-[#ff3b3b22] border border-[#ff3b3b44] rounded-full">
                <AlertCircle size={8} className="text-[#ff3b3b] animate-pulse" />
                <span className="text-[7px] text-[#ff3b3b] font-bold uppercase">Throttled</span>
              </div>
            )}
          </div>
          <MetricTag label="Vitality" value={state.telemetry.SVI} color="#00eaff" />
          <MetricTag label="Momentum" value={state.telemetry.OM} color="#ffcc00" />
          <MetricTag label="Pressure" value={state.telemetry.AP} color="#ff3b3b" />
        </div>

        <div className="pt-6 border-t border-[#1a3a45] space-y-4 pointer-events-auto">
          <h3 className="text-[9px] uppercase tracking-[0.3em] text-[#8899a6] font-black">Stability_Conservation</h3>
          
          <ResourceBar label="Phase_Poten" value={phi} max={100} color="#00eaff" icon={<Activity size={10} />} />
          <ResourceBar label="Readiness" value={readiness} max={100} color="#00ff41" icon={<TrendingUp size={10} />} />
          <ResourceBar label="Kinetic_En" value={energy} max={100} color="#ffcc00" icon={<Zap size={10} />} />
          
          <div className="flex justify-between items-center text-[7px] tracking-widest uppercase text-[#8899a6] mt-2">
             <span>Recovery_Buffer</span>
             <span className="text-[#00ff41]">ACTIVE</span>
          </div>
          <div className="flex gap-1">
             {Array.from({ length: 10 }).map((_, i) => (
                <div key={i} className={`flex-1 h-1 ${i < (meridian.vitalityIndex / 10) ? 'bg-[#00ff41]' : 'bg-[#1a3a45]'} rounded-full`} />
             ))}
          </div>
          
          <div className="mt-4 p-2 bg-[#00eaff08] border border-[#00eaff22] rounded-xs">
            <div className="flex justify-between items-center mb-1">
              <span className="text-[7px] uppercase text-[#8899a6]">Envelope_W</span>
              <span className="text-[8px] font-mono text-[#00eaff]">{(energy + 1.0*phi + 0.5*readiness).toFixed(1)} / 150</span>
            </div>
            <div className="w-full h-1 bg-[#1a3a45] rounded-full overflow-hidden">
               <div 
                 className="h-full bg-gradient-to-r from-[#00eaff] to-[#ff3b3b]" 
                 style={{ width: `${Math.min(100, (energy + 1.0*phi + 0.5*readiness) / 1.5)}%` }} 
               />
            </div>
          </div>
        </div>
      </div>

      {/* Right Sidebar: Active Node Protocol */}
      <AnimatePresence>
        {state.ui.selectedSignalId && (
          <motion.div 
            initial={{ x: 400, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: 400, opacity: 0 }}
            className="absolute right-0 top-0 bottom-0 w-80 glass-panel-heavy border-l border-[#00eaff22] p-8 pointer-events-auto"
          >
            <div className="space-y-8">
               <div className="border-b border-[#00eaff44] pb-4">
                  <h2 className="text-[10px] uppercase tracking-[0.3em] text-[#00eaff] opacity-60 mb-2 font-black">Node_Focus_Engaged</h2>
                  <div className="text-xl text-white font-black tracking-tighter uppercase">{state.ui.selectedSignalId}</div>
               </div>

               <div className="space-y-6">
                  <div className="space-y-2">
                    <div className="text-[8px] uppercase tracking-widest text-[#8899a6] font-bold">Resonance_Sync</div>
                    <div className="w-full h-1 bg-[#1a3a45] rounded-full overflow-hidden">
                       <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: '75%' }}
                        className="h-full bg-gradient-to-r from-[#00eaff] to-[#00ff41]" 
                       />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                     <div className="bg-[#05070a] p-3 border border-[#1a3a45]">
                        <div className="text-[7px] text-[#8899a6] uppercase mb-1">State</div>
                        <div className="text-sm font-bold text-[#00ff41]">NOMINAL</div>
                     </div>
                     <div className="bg-[#05070a] p-3 border border-[#1a3a45]">
                        <div className="text-[7px] text-[#8899a6] uppercase mb-1">Drift</div>
                        <div className="text-sm font-bold text-[#ffcc00]">CORRECTED</div>
                     </div>
                  </div>
               </div>

               <div className="space-y-4 py-8 border-t border-[#1a3a45]">
                  <h3 className="text-[9px] uppercase tracking-[0.2em] text-[#00eaff] font-bold">Autonomous_Operator_Logs</h3>
                  <div className="space-y-3">
                     <LogItem text="Node_activation_sequence_complete" time="0.4ms" />
                     <LogItem text="Synthesis_lattice_balanced" time="1.2ms" />
                     <LogItem text="Drift_anomaly_detected_and_purged" time="2.8ms" color="text-[#ff3b3b]" />
                  </div>
               </div>

               <button 
                onClick={() => handleSelectNode("")}
                className="w-full py-3 border border-[#ff3b3b44] text-[#ff3b3b] text-[9px] uppercase font-black tracking-[0.3em] hover:bg-[#ff3b3b11] transition-colors"
               >
                 Disengage_Focus
               </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Footer Navigation: Mode Switching — FINAL LOCK */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-8 glass-panel-heavy border border-[#00eaff22] px-10 py-3 rounded-xs">
          <ModeIcon active={focusMode === 'SCAN'} icon={<LayoutGrid size={14} />} label="Scan" onClick={() => setFocusMode('SCAN')} />
          <ModeIcon active={focusMode === 'FOCUS'} icon={<Target size={14} />} label="Focus" onClick={() => setFocusMode('FOCUS')} />
          <ModeIcon active={focusMode === 'SIMULATE'} icon={<Cpu size={14} />} label="Sim" onClick={() => setFocusMode('SIMULATE')} />
      </div>

      <Notifications />
    </div>
  );
}

function ResourceBar({ label, value, max, color, icon }: { label: string, value: number, max: number, color: string, icon: any }) {
  return (
    <div className="flex flex-col gap-1">
       <div className="flex justify-between items-center text-[7px] tracking-widest uppercase">
          <div className="flex items-center gap-1.5 text-[#8899a6]">
             {icon}
             <span>{label}</span>
          </div>
          <span style={{ color }}>{value.toFixed(0)}</span>
       </div>
       <div className="w-32 h-0.5 bg-[#1a3a45] rounded-full overflow-hidden">
          <motion.div 
            initial={{ width: 0 }}
            animate={{ width: `${(value / max) * 100}%` }}
            className="h-full"
            style={{ backgroundColor: color }}
          />
       </div>
    </div>
  );
}

function ModeIcon({ icon, label, onClick, active }: { icon: any, label: string, onClick: () => void, active: boolean }) {
  return (
    <button onClick={onClick} className={`flex flex-col items-center gap-1 group transition-all ${active ? 'scale-110' : 'opacity-40 hover:opacity-80'}`}>
       <div className={`transition-colors ${active ? 'text-[#00eaff]' : 'text-[#8899a6]'}`}>{icon}</div>
       <span className={`text-[7px] uppercase tracking-widest ${active ? 'text-[#00eaff] font-black' : 'text-[#8899a6]'}`}>{label}</span>
       {active && <motion.div layoutId="lattice-mode-indicator" className="w-4 h-[1px] bg-[#00eaff] mt-0.5" />}
    </button>
  );
}

function MetricTag({ label, value, color }: { label: string, value: number, color: string }) {
  return (
    <div className="flex flex-col">
       <span className="text-[7px] uppercase tracking-[0.4em] text-[#8899a6] font-black mb-1">{label}</span>
       <div className="flex items-center gap-2">
          <div className="w-16 h-0.5 bg-[#1a3a45] overflow-hidden">
             <div className="h-full" style={{ width: `${value}%`, backgroundColor: color }} />
          </div>
          <span className="text-[10px] font-mono font-bold" style={{ color }}>{value.toFixed(1)}</span>
       </div>
    </div>
  );
}

function LogItem({ text, time, color = "text-[#8899a6]" }: { text: string, time: string, color?: string }) {
  return (
    <div className="flex justify-between items-center bg-[#05070a] p-2 border border-[#1a3a4533]">
       <span className={`text-[8px] uppercase tracking-tighter ${color}`}>{text}</span>
       <span className="text-[7px] opacity-30 font-mono">{time}</span>
    </div>
  );
}

function NavIcon({ icon, label, onClick }: { icon: any, label: string, onClick: () => void }) {
  return (
    <button onClick={onClick} className="flex flex-col items-center gap-1 group">
       <div className="text-[#8899a6] group-hover:text-[#00eaff] transition-colors">{icon}</div>
       <span className="text-[7px] uppercase tracking-widest text-[#8899a6] opacity-40 group-hover:opacity-100">{label}</span>
    </button>
  );
}
